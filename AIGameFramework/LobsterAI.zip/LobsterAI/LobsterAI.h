

class PlayerController;
namespace LobsterAI
{
	PlayerController* createNewPlayer();	
}



